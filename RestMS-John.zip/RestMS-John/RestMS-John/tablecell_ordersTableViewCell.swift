//
//  tablecell_ordersTableViewCell.swift
//  RestMS-John
//
//  Created by Johnson Khristi on 2017-11-11.
//  Copyright © 2017 xcode. All rights reserved.
//

import UIKit

class tablecell_ordersTableViewCell: UITableViewCell {
    @IBOutlet weak var txttotalorders: UILabel!
    
    @IBOutlet weak var txtxprofit: UILabel!
    @IBOutlet weak var txtlocation: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
