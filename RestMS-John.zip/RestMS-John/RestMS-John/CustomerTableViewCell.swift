//
//  CustomerTableViewCell.swift
//  RestMS-John
//
//  Created by Johnson Khristi on 2017-11-11.
//  Copyright © 2017 xcode. All rights reserved.
//

import UIKit

class CustomerTableViewCell: UITableViewCell {

    @IBOutlet weak var txtorders: UILabel!
    @IBOutlet weak var cust_category: UILabel!
    @IBOutlet weak var txtcustname: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
