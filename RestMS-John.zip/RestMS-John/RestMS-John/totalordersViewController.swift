//
//  totalordersViewController.swift
//  RestMS-John
//
//  Created by Johnson Khristi on 2017-11-11.
//  Copyright © 2017 xcode. All rights reserved.
//

import UIKit

class totalordersViewController: UIViewController , UITableViewDataSource{
    
    
    
    var locations : [String] = ["Tim Downtown", "Tim Lambton", "Tim Seneca", "Tim Humber", "Tim Centennial"]
    var profit : [Double] = [12500.00 , 8560.20, 6538.00, 26953.00, 15920.00]
    var totalorders_number : [Int] = [12658, 6800, 6500, 15930, 1620]
    
    
    @IBOutlet weak var tableorders: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        tableorders.delegate = self as? UITableViewDelegate
        tableorders.dataSource = self
        
        //tableorders.estimatedRowHeight = 50
        //tableorders.rowHeight = UITableViewAutomaticDimension
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return locations.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let  cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! tablecell_ordersTableViewCell
        
        cell.txtlocation.text = locations[indexPath.row]
        cell.txtxprofit.text = String (profit[indexPath.row] )
        cell.txttotalorders.text = String (totalorders_number[indexPath.row] )

        print(locations[indexPath.row])
        
        return cell 
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
